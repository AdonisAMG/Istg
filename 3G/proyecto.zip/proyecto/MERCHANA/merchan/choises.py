estado=(
    ('si','Activo'),
    ('no','Inactivo')
)