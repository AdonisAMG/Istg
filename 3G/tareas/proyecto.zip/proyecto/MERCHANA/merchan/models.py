from django.db import models

# Create your models here.

class cita_medica (models.Model):

    id_cm=models.IntegerField(primary_key=True)

    doctor=doctor=models.ForeignKey(doctor)
    
    paciente=models.ForeignKey(paciente)
    
    motivo=models.CharField(max_length=200)
    
    hospital=models.ForeignKey(hospital)
    
    sucursal=models.ForeignKey(sucursal)
    
    def __str__(self):

        return self.id_cm



class cita_medica_tratamiento(models.Model)

    id_cmt=models.IntegerField(primary_key=True)
    
    cita_medica=models.ForeignKey(cita_medica)
    
    producto=models.ForeignKey(producto)
    
    cantidad=models.IntegerField()
    
    tratamiento=models.CharField(max_length=500)   
    def __str__(self):

        return self.id_cmt



class hospital (models.Model):

    nombre=models.CharField(max_length=200)

    ubicacion=models.CharField(max_length=200)
    
    doctor=models.ForeignKey(doctor)
    
    nmr_telefono=models.IntegerField()
    
    paciente=models.ForeignKey(paciente)
    
    imagen=models.ImageField(upload_to="merchan")

    fechacreacion=models.DateTimeField(auto_now_add=True)

    def __str__(self):

        return self.nombre



class sucursal(models.Model):

    ubicacion=models.CharField(max_length=200)
    
    doctor=models.ForeignKey(doctor)
    
    nmr_telefono=models.IntegerField()
    
    paciente=models.ForeignKey(paciente)

    imagen=models.ImageField(upload_to="merchan")

    fechacreacion=models.DateTimeField(auto_now_add=True)

    def __str__(self):

        return self.nombre



class paciente(models.Model):

    nombres=models.CharField(max_length=200)

    apellidos = models.CharField(max_length=200)
    
    direccion = models.CharField(max_length=200)
    
    nmr_telefono=models.IntegerField()
    
    direccion = models.CharField(max_length=200)

    imagen=models.ImageField(upload_to="merchan")

    fechacreacion=models.DateTimeField(auto_now_add=True)

    fechamodificacion=models.DateTimeField(auto_now=True)

    def __str__(self):

        return self.nombres



class doctor(models.Model):

    nombres=models.CharField(max_length=200)

    apellidos = models.CharField(max_length=200)
    
    nmr_telefono=models.IntegerField()

    imagen=models.ImageField(upload_to="merchan")

    fechacreacion=models.DateTimeField(auto_now_add=True)

    fechamodificacion=models.DateTimeField(auto_now=True)

    def __str__(self): 

        return self.nombres



class producto(models.Model):

    nombre=models.CharField(max_length=200)
    
    precio=models.IntegerField()

    imagen=models.ImageField(upload_to="merchan")

    fechacreacion=models.DateTimeField(auto_now_add=True)

    fechamodificacion=models.DateTimeField(auto_now=True)

    def __str__(self):

        return self.nombre
        