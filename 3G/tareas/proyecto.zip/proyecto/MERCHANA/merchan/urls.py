from django.urls import path

from . import views

from .views import *
#CitaListview,CitaGuardarCreateView,CitaModificarUpdateview,CitaBorrarDeleteview
from django.conf import settings



urlpatterns = [

    path('', views.cita_medica, name='cita_medica'),

    path('cita_medica_tratamiento', views.cita_medica_tratamiento, name='cita_medica_tratamiento'),

    path('hospital', views.hospital, name='hospital'),
    
    path('sucursal', views.sucursal, name='sucursal'),

    path('paciente',views.paciente,name='paciente'),

    path('doctor',views.doctor,name='doctor'), 
    
    path('producto',views.producto,name='producto'),
    
    path('login/', views.login, name='login'),


    # llamar a las vistas de clases
    path('CitaListview/',CitaListview.as_view(),name='CitaListview'),
    path('CitaCreateview/',CitaGuardarCreateView.as_view(),name='CitaCreateview'),
    path('CitaUpdateView/<int:pk>',CitaModificarUpdateview.as_view(),name='CitaUpdateView'),
    path('CitaDeleteview/<int:pk>', CitaBorrarDeleteview.as_view(),name='CitaDeleteview'),

    path('TratamientoListview/',TratamientoListview.as_view(),name='TratamientoListview'),
    path('TratamientoCreateview/',TratamientoGuardarCreateView.as_view(),name='TratamientoCreateview'),
    path('TratamientoUpdateView/<int:pk>',TratamientoModificarUpdateview.as_view(),name='TratamientoUpdateView'),
    path('TratamientoDeleteview/<int:pk>',TratamientoBorrarDeleteview.as_view(),name='TratamientoDeleteview'),

    path('HospitalListview/',HospitalListview.as_view(),name='HospitalListview'),
    path('HospitalCreateview/', HospitalGuardarCreateView.as_view(),name='HospitalCreateview'),
    path('HospitalUpdateView/<int:pk>', HospitalModificarUpdateview.as_view(),name='HospitalUpdateView'),
    path('HospitalDeleteview/<int:pk>', HospitalBorrarDeleteview.as_view(),name='HospitalDeleteview'),

    path('CitaListview/',CitaListview.as_view(),name='CitaListview'),
    path('CitaCreateview/',CitaGuardarCreateView.as_view(),name='CitaCreateview'),
    path('CitaUpdateView/<int:pk>',CitaModificarUpdateview.as_view(),name='CitaUpdateView'),
    path('CitaDeleteview/<int:pk>', CitaBorrarDeleteview.as_view(),name='CitaDeleteview'),

    path('CitaListview/',CitaListview.as_view(),name='CitaListview'),
    path('CitaCreateview/',CitaGuardarCreateView.as_view(),name='CitaCreateview'),
    path('CitaUpdateView/<int:pk>',CitaModificarUpdateview.as_view(),name='CitaUpdateView'),
    path('CitaDeleteview/<int:pk>', CitaBorrarDeleteview.as_view(),name='CitaDeleteview'),

    path('CitaListview/',CitaListview.as_view(),name='CitaListview'),
    path('CitaCreateview/',CitaGuardarCreateView.as_view(),name='CitaCreateview'),
    path('CitaUpdateView/<int:pk>',CitaModificarUpdateview.as_view(),name='CitaUpdateView'),
    path('CitaDeleteview/<int:pk>', CitaBorrarDeleteview.as_view(),name='CitaDeleteview'),

    path('CitaListview/',CitaListview.as_view(),name='CitaListview'),
    path('CitaCreateview/',CitaGuardarCreateView.as_view(),name='CitaCreateview'),
    path('CitaUpdateView/<int:pk>',CitaModificarUpdateview.as_view(),name='CitaUpdateView'),
    path('CitaDeleteview/<int:pk>', CitaBorrarDeleteview.as_view(),name='CitaDeleteview'),

