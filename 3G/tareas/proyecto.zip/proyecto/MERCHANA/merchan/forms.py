from django import forms
from .models import cita_medica


class Medicinaform(forms.Form):
    name=forms.CharField(label="Nombre",required=True)
    emai=forms.EmailField(label="Email",required=True)
    contenido=forms.CharField(label="Contenido",required=True)


class medicinaformulario(forms.ModelForm):
    class Meta:
        model= cita_medica     
        fields=['doctor','paciente','producto','cantidad','tratamiento','hospital','sucursal']


class usuarioform(forms.Form): 
     username=forms.CharField(label="usuario",required=True,max_length=15)
     password=forms.CharField(label="clave",required=True,max_length=10)