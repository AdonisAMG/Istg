from django.shortcuts import render, redirect

from .models import cita_medica, cita_medica_tratamiento, hospital, sucursal, paciente, doctor, producto

from .forms import Contactform, medicinaformulario, tratamientoformulario, hospitalformulario, sucursalformulatio, pacienteformulario, doctorformulario, productoformulario, usuarioform

from django.contrib.auth import authenticate

from django.views.generic.list import ListView

from django.views.generic.edit import CreateView, UpdateView, DeleteView

from django.urls import reverse_lazy



# Create your views here.

def cita_medica(request):
    objcontacto = Medicinaform()
    print("Valida datos")
    if request.method == "POST":
        objcontacto = Contactform(request.POST)
        print("carga datos")
        if objcontacto.is_valid():
            print(objcontacto)
    return render(request, 'cita_medica.html', {"forms": objcontacto})


def cita_medica_tratamiento(request):
    objCondatos = cita_medica.objects.all()
    return render(request, 'cita_medica_tratamiento.html', {'Enviacmt': objCondatos})


def hospital(request):
    objCondatos = hospital.objects.all()
    return render(request, 'hospital.html', {'Enviah': objCondatos})


def sucursal(request):
    objCondatos = sucursal.objects.all()
    return render(request, 'sucursal.html', {'Envias': objCondatos})
    
    
def paciente(request):
    objCondatos = paciente.objects.all()
    return render(request, 'paciente.html', {'Enviap': objCondatos})


def doctor(request):
    objCondatos = doctor.objects.all()
    return render(request, 'doctor.html', {'Enviad': objCondatos})
     
    
def producto(request):
    objCondatos = producto.objects.all()
    return render(request, 'producto.html', {'Enviapo': objCondatos})



# Create your views here.

def cita_medica(request):
    objCondatos = cita_medica.objects.all()
    if request.method == "POST":
        titulo = request.POST.get('titulo')
        if titulo == '':
            print("Espacio en Blanco")
        else:
            print("Debe realizar la busqueda por el titulo")
            objCondatos = cita_medica.objects.filter(titulo=titulo)
    return render(request, 'cita_medica.html', {'Enviablog': objCondatos})
    


def cita_medica_tratamiento(request):
    objCondatos = cita_medica_tratamiento.objects.all()
    if request.method == "POST":
        titulo = request.POST.get('titulo')
        if titulo == '':
            print("Espacio en Blanco")
        else:
            print("Debe realizar la busqueda por el titulo")
            objCondatos = cita_medica_tratamiento.objects.filter(titulo=titulo)
    return render(request, 'cita_medica_tratamiento.html', {'Enviablog': objCondatos})



def hospital(request):
    objCondatos = hospital.objects.all()
    if request.method == "POST":
        titulo = request.POST.get('titulo')
        if titulo == '':
            print("Espacio en Blanco")
        else:
            print("Debe realizar la busqueda por el titulo")
            objCondatos = hospital.objects.filter(titulo=titulo)
    return render(request, 'hospital.html', {'Enviablog': objCondatos})
    
    
    
def sucursal(request):
    objCondatos = sucursal.objects.all()
    if request.method == "POST":
        titulo = request.POST.get('titulo')
        if titulo == '':
            print("Espacio en Blanco")
        else:
            print("Debe realizar la busqueda por el titulo")
            objCondatos = sucursal.objects.filter(titulo=titulo)
    return render(request, 'sucursal.html', {'Enviablog': objCondatos})
    
    
    
def paciente(request):
    objCondatos = paciente.objects.all()
    if request.method == "POST":
        titulo = request.POST.get('titulo')
        if titulo == '':
            print("Espacio en Blanco")
        else:
            print("Debe realizar la busqueda por el titulo")
            objCondatos = paciente.objects.filter(titulo=titulo)
    return render(request, 'paciente.html', {'Enviablog': objCondatos})



def doctor(request):
    objCondatos = doctor.objects.all()
    if request.method == "POST":
        titulo = request.POST.get('titulo')
        if titulo == '':
            print("Espacio en Blanco")
        else:
            print("Debe realizar la busqueda por el titulo")
            objCondatos = doctor.objects.filter(titulo=titulo)
    return render(request, 'doctor.html', {'Enviablog': objCondatos})



def producto(request):
    objCondatos = produco.objects.all()
    if request.method == "POST":
        titulo = request.POST.get('titulo')
        if titulo == '':
            print("Espacio en Blanco")
        else:
            print("Debe realizar la busqueda por el titulo")
            objCondatos = producto.objects.filter(titulo=titulo)
    return render(request, 'producto.html', {'Enviablog': objCondatos})



def login(request):
    form = usuarioform()
    if request.method == "POST":
        form = usuarioform(request.POST)
        if form.is_valid():
            username = form.cleaned_data['username']
            password = form.cleaned_data['password']
            user = authenticate(username=request.POST['username'], password=request.POST['password'])
            if user is not None:
                return redirect("cita_medica")
    return render(request, 'login.html', {'form': form})



# ------Vistas basadas en clases----------

class CitaListview(ListView):
    model = cita_medica
    paginate_by = 10
    template_name = 'Citaclase.html'

class CitaGuardarCreateView(CreateView):
    model = cita_medica
    form_class = citaformulario
    template_name = 'CitaGuardarClase.html'
    def get_success_url(self):
        return reverse_lazy('CitaListview')

class CitaModificarUpdateview(UpdateView):
    model = cita_medica
    form_class = citaformulario
    template_name = 'CitaModificarClase.html'
    def get_success_url(self):
        return reverse_lazy('CitaListview')

class CitaBorrarDeleteview(DeleteView):
    model = cita_medica
    template_name = 'CitaEliminarClase.html'
    success_url = reverse_lazy('CitaListview')





class TratamientoListview(ListView):
    model = cita_medica_tratamiento
    paginate_by = 10
    template_name = 'Tratamientoclase.html'

class TratamientoGuardarCreateView(CreateView):
    model = cita_medica_tratamiento
    form_class = Tratamientoformulario
    template_name = 'TratamientoGuardarClase.html'
    def get_success_url(self):
        return reverse_lazy('TratamientoListview')

class TratamientoModificarUpdateview(UpdateView):
    model = cita_medica_tratamiento
    form_class = tratamientoformulario
    template_name = 'TratamientoModificarClase.html'
    def get_success_url(self):
        return reverse_lazy('TratamientoListview')

class TratamientoBorrarDeleteview(DeleteView):
    model = cita_medica_tratamiento
    template_name = 'TratamientoEliminarClase.html'
    success_url = reverse_lazy('TratamientoListview')





class HospitalListview(ListView):
    model = hospital
    paginate_by = 10
    template_name = 'Hospitalclase.html'

class HospitalGuardarCreateView(CreateView):
    model = hospital
    form_class = hospitalformulario
    template_name = 'HospitalGuardarClase.html'
    def get_success_url(self):
        return reverse_lazy('HospitalListview')

class HospitalModificarUpdateview(UpdateView):
    model = hospital
    form_class = hospitalformulario
    template_name = 'HospitalModificarClase.html'
    def get_success_url(self):
        return reverse_lazy('HospitalListview')

class HospitalBorrarDeleteview(DeleteView):
    model = hospital
    template_name = 'HospitalEliminarClase.html'
    success_url = reverse_lazy('HospitalListview')





class SucursalListview(ListView):
    model = cita_medica
    paginate_by = 10
    template_name = 'Medicinaclase.html'

class SucursalGuardarCreateView(CreateView):
    model = sucursal
    form_class = sucursalformulario
    template_name = 'SuirsalGuardarClase.html'
    def get_success_url(self):
        return reverse_lazy('SucursalListview')

class SucursalModificarUpdateview(UpdateView):
    model = sucursal
    form_class = sucursalformulario
    template_name = 'SucursalModificarClase.html'
    def get_success_url(self):
        return reverse_lazy('SucursalListview')

class SucursalBorrarDeleteview(DeleteView):
    model = sucursal
    template_name = 'SucursalEliminarClase.html'
    success_url = reverse_lazy('SucursalListview')





class PacienteListview(ListView):
    model = paciente
    paginate_by = 10
    template_name = 'Pacienteclase.html'

class PacienteGuardarCreateView(CreateView):
    model = paciente 
    form_class = pacienteformulario
    template_name = 'PacienteGuardarClase.html'
    def get_success_url(self):
        return reverse_lazy('PacienteListview')

class PacienteModificarUpdateview(UpdateView):
    model = paciente 
    form_class = pacienteformulario
    template_name = 'PacienteModificarClase.html'
    def get_success_url(self):
        return reverse_lazy('PacienteListview')

class PacienteBorrarDeleteview(DeleteView):
    model = paciente
    template_name = 'PacienteEliminarClase.html'
    success_url = reverse_lazy('PacieneListview')





class DoctorListview(ListView):
    model = doctor
    paginate_by = 10
    template_name = 'Doctorclase.html'

class DoctorGuardarCreateView(CreateView):
    model = doctor
    form_class = doctorformulario
    template_name = 'DoctorGuardarClase.html'
    def get_success_url(self):
        return reverse_lazy('DoctorListview')

class DoctorModificarUpdateview(UpdateView):
    model = doctor
    form_class = doctorformulario
    template_name = 'DoctorModificarClase.html'
    def get_success_url(self):
        return reverse_lazy('DoctorListview')

class DoctorBorrarDeleteview(DeleteView):
    model = doctor
    template_name = 'DoctorEliminarClase.html'
    success_url = reverse_lazy('DoctorListview')





class ProductoListview(ListView):
    model = producto
    paginate_by = 10
    template_name = 'Productoclase.html'

class ProductoGuardarCreateView(CreateView):
    model = producto
    form_class = productoformulario
    template_name = 'ProductoGuardarClase.html'
    def get_success_url(self):
        return reverse_lazy('ProductoListview')

class ProductoModificarUpdateview(UpdateView):
    model = producto
    form_class = productoformulario
    template_name = 'ProductoModificarClase.html'
    def get_success_url(self):
        return reverse_lazy('ProductoListview')

class ProductoBorrarDeleteview(DeleteView):
    model = producto
    template_name = 'ProductoEliminarClase.html'
    success_url = reverse_lazy('ProductoListview')





