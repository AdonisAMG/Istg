from django.contrib import admin
from .models import noticiasM
from .models import inicioM
# Register your models here.
admin.site.register(noticiasM)
admin.site.register(inicioM)