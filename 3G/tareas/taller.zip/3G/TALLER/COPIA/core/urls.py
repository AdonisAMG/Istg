from django.urls import path
from . import views


urlpatterns = [
    path('', views.holamundoCore, name='core'),

    path('NOTICIA', views.noticias, name='noticias'),

    path('DEPORTES', views.deportes, name='deportes'),

    path('FARANDULA', views.farandula, name='farandula'),
]