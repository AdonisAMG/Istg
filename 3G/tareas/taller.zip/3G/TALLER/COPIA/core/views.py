from django.shortcuts import render

# Create your views here.
def holamundoCore(request):
    return render(request,'core.html')

def noticias(request):
    return render(request,'noticias.html')

def deportes(request):
    return render(request,'deportes.html')

def farandula(request):
    return render(request,'farandula.html')