from django.shortcuts import render

# Create your views here.
def proyecto(request):
    return render(request,'inicio.html')

def nuestros_productos(request):
    return render(request,'nuestros_productos.html')

def quienes_somos(request):
    return render(request,'quienes_somos.html')

def contactos(request):
    return render(request,'contactos.html')

def QUIENES__SOMOS(request):
    return render(request,'QUIENES SOMOS.html')
