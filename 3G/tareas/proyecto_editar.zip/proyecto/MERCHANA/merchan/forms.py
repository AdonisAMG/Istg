from django import forms
from .models import empresa

class Contactform(forms.Form):
    name=forms.CharField(label="Nombre",required=True)
    emai=forms.EmailField(label="Email",required=True)
    contenido=forms.CharField(label="Contenido",required=True)

class medicinaformulario(forms.ModelForm):
    class Meta:
        model= empresa
        fields=['nombre','ubicacion','imagen']

class usuarioform(forms.Form):
    username=forms.CharField(label="usuario",required=True,max_length=15)
    password=forms.CharField(label="clave",required=True,max_length=10)