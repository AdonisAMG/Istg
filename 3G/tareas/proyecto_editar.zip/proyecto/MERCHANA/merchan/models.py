from django.db import models
# Create your models here.
class empresa (models.Model):
    nombre=models.CharField(max_length=200)
    ubicacion=models.CharField(max_length=200)
    imagen=models.ImageField(upload_to="merchan")
    fechacreacion=models.DateTimeField(auto_now_add=True)
    def __str__(self):
        return self.nombre

class sucursal(models.Model):
    nombre=models.CharField(max_length=200)
    ubicacion=models.CharField(max_length=200)
    imagen=models.ImageField(upload_to="merchan")
    fechacreacion=models.DateTimeField(auto_now_add=True)
    def __str__(self):
        return self.nombre

class paciente(models.Model):
    nombres=models.CharField(max_length=200)
    apellidos = models.CharField(max_length=200)
    imagen=models.ImageField(upload_to="inicio")
    fechacreacion=models.DateTimeField(auto_now_add=True)
    fechamodificacion=models.DateTimeField(auto_now=True)
    def __str__(self):
        return self.nombres

class doctor(models.Model):
    nombres=models.CharField(max_length=200)
    apellidos = models.CharField(max_length=200)
    imagen=models.ImageField(upload_to="inicio")
    fechacreacion=models.DateTimeField(auto_now_add=True)
    fechamodificacion=models.DateTimeField(auto_now=True)
    def __str__(self):
        return self.nombres

class atencion_medica(models.Model):
    id=models.IntegerField(primary_key=True)
    encargado=models.ForeignKey(encargado, on_delete=models.CASCADE)
    paciente=models.ForeignKey(paciente, on_delete=models.CASCADE)
    receta=models.ForeignKey(receta, on_delete=models.CASCADE)
    fechacreacion=models.DateTimeField(auto_now_add=True)
    fechamodificacion=models.DateTimeField(auto_now=True)
    def __str__(self):
        return self.id

class receta(models.Model):
    producto=models.CharField(max_length=200)
    contenido=models.TextField()
    doctor=models.ForeignKey(doctor, on_delete=models.CASCADE)
    fechacreacion=models.DateTimeField(auto_now_add=True)
    fechamodificacion=models.DateTimeField(auto_now=True)
    def __str__(self):
        return self.producto

class encargado(models.Model):
    nombres=models.CharField(max_length=200)
    apellidos = models.CharField(max_length=200)
    imagen=models.ImageField(upload_to="inicio")
    fechacreacion=models.DateTimeField(auto_now_add=True)
    fechamodificacion=models.DateTimeField(auto_now=True)
    def __str__(self):
        return self.nombres
