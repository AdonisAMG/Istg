from django.shortcuts import render, redirect
from .models import empresa, sucursal, paciente, doctor, atencion_medica, receta, encargado
from .forms import Contactform, medicinaformulario, usuarioform
from django.contrib.auth import authenticate
from django.views.generic.list import ListView
from django.views.generic.edit import CreateView, UpdateView, DeleteView
from django.urls import reverse_lazy

# Create your views here.
def inicio(request):
    objCondatos = inicioM.objects.all()
    return render(request, 'inicio.html', {'Enviainicio': objCondatos})

def deportes(request):
    return render(request, 'deportes.html')

def farandula(request):
    return render(request, 'farandula.html')

def email(request):
    return render(request, 'email.html')

def contacto(request):
    objcontacto = Contactform()
    print("Valida post")
    if request.method == "POST":
        objcontacto = Contactform(request.POST)
        print("carga datos post")
        if objcontacto.is_valid():
            print(objcontacto)
    return render(request, 'contacto.html', {"forms": objcontacto})


# Create your views here.
def noticias(request):
    objCondatos = noticiasM.objects.all()
    if request.method == "POST":
        titulo = request.POST.get('titulo')
        if titulo == '':
            print("Espacio en Blanco")
        else:
            print("Debe realizar la busqueda por el titulo")
            objCondatos = noticiasM.objects.filter(titulo=titulo)
    return render(request, 'noticias.html', {'Enviablog': objCondatos})


def login(request):
    # creamos el formulario de autentificacion vacio
    form = usuarioform()
    if request.method == "POST":
        # Añadimos los datos recibidos al formulario
        form = usuarioform(request.POST)
        if form.is_valid():
            # Recuperamos las credenciales validadas
            username = form.cleaned_data['username']
            password = form.cleaned_data['password']
            user = authenticate(username=request.POST['username'], password=request.POST['password'])
            if user is not None:
                return redirect("noticias")
    return render(request, 'login.html', {'form': form})

# ------Vistas basadas en clases----------

class noticiasListview(ListView):
    model = empresa
    paginate_by = 10
    template_name = 'medicinaclase.html'

class noticiasGuardarCreateView(CreateView):
    model = empresa
    form_class = medicinaformulario
    template_name = 'noticiasGuardarClase.html'
    def get_success_url(self):
        return reverse_lazy('noticiasListview')

class noticiasModificarUpdateview(UpdateView):
    model = empresa
    form_class = medicinaformulario
    template_name = 'noticiasModificarClase.html'
    def get_success_url(self):
        return reverse_lazy('noticiasListview')

class noticiasBorrarDeleteview(DeleteView):
    model = empresa
    template_name = 'noticiasEliminarClase.html'
    success_url = reverse_lazy('noticiasListview')
