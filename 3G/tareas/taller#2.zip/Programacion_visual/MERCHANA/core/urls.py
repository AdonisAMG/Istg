from django.urls import path
from . import views
from django.conf import settings

urlpatterns = [
    path('', views.inicio, name='inicio'),

    path('noticias', views.noticias, name='noticias'),

    path('deportes', views.deportes, name='deportes'),

    path('farandula', views.farandula, name='farandula'),

    path('email',views.email,name='email'),

    path('contacto',views.contacto,name='contacto'),

    path('noticiasAgregar/', views.addnoticias, name='noticiasAgregar'),

    path('noticiasmodificar/<int:id>', views.addmodificar, name='noticiasmodificar'),

    path('noticiaeliminar/<int:id>',views.eliminarnoticia,name='noticiaeliminar'),

    path('login/', views.login, name='login'),




    path('inicioH',views.inicioH, name='inicioH'),

    path('deportesH', views.deportesH, name='deportesH'),

    path('farandulaH', views.farandulaH, name='farandulaH'),

    path('noticiasH', views.noticiasH, name='noticiasH'),

]